# -*- coding: utf-8 -*-
"""
Created on Sat Jan 25 22:09:50 2020

@author: SONY
"""


'''
lst = ['a','b',[4,10,11],['c',[1,66,['this']],2,111], 'e', 7]
print(lst[3][1][2])

d = {'k1':['val1','val2','val3',{'we':['need','to','go',{'deeper':[1,2,3,'that']}]}]}
print(d['k1'][3]['we'][3]['deeper'][3])

correo= 'user@domain.com'
print(correo.split('@')[-1])

comparar = 'The Internet Engineering Task Force was created in 1986'
print('internet' in comparar.lower())


text='I don\'t know how to spell IoT ! Is it IoT or iot ? What does iot mean anyway?'
print([  x.lower() for x in text.split(' ')])
print([ 'iot' in x.lower() for x in text.split(' ')])
L=[ 'iot' in x.lower() for x in text.split(' ')]
print('print L')
print(L)
L1 = len(list( filter(lambda x: x ==True, L   )))
print('L1') 
print(L1)
seq = ['data','salt' ,'dairy','cat', 'dog']

print(list(filter(lambda x: x.startswith('d')==False ,seq)))
'''


class Elevator:
    
    def __init__(self, floor_numbers, floor_types):
        self._floor_numbers = floor_numbers
        self._floor_types = floor_types
        self._number_to_type_dict = dict(zip(floor_numbers, floor_types)) 
        self._type_to_number_dict = dict(zip(floor_types, floor_numbers)) 
        
    def ask_which_floor(self, floor_type):    
        if floor_type in self._floor_types:
            print('The {} floor is the number: {}.'.format(floor_type, self._type_to_number_dict[floor_type]))
        else:
            print('There is no {} floor in this building.'.format(floor_type))
    
    def go_to_floor(self, floor_number):
        if floor_number in self._floor_numbers:
            print('go to floor of {}.'.format(self._number_to_type_dict[floor_number]))
        else:
            print('in this building there is no the floor number {}'.format(floor_number))
            

floor_types = ['Estacionamiento', 'Negocios', 'Área de restaurantes', 'Oficinas'] 
floor_numbers = list(range(-1,4))
print(floor_numbers)
el = Elevator(floor_numbers, floor_types)
el.go_to_floor(1)